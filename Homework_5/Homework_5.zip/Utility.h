#pragma once
#include <string>
using namespace std;
using namespace System;

class Utility
{
public:
	Utility(void);
//	static string StringToStdString(String^ str);
};

